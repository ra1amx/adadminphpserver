all files in the root, do not create any folder in the zip archive
html file shown is "index.html".
in index.html you can include javascript files, images and css files.
